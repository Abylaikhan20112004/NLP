import numpy as np
import re

class Model:
    def __init__(self, alpha=1):
        self.vocab = set() # словарь, содержащий все уникальные слова из набора train
        self.spam = {} # словарь, содержащий частоту слов в спам-сообщениях из набора данных train.
        self.ham = {} # словарь, содержащий частоту слов в не спам-сообщениях из набора данных train.
        self.alpha = alpha # сглаживание
        self.label2num = None # словарь, используемый для преобразования меток в числа
        self.num2label = None # словарь, используемый для преобразования числа в метки
        self.Nvoc = None # общее количество уникальных слов в наборе данных train
        self.Nspam = None # общее количество уникальных слов в спам-сообщениях в наборе данных train
        self.Nham = None # общее количество уникальных слов в не спам-сообщениях в наборе данных train
        self._train_X, self._train_y = None, None
        self._val_X, self._val_y = None, None
        self._test_X, self._test_y = None, None

    def fit(self, dataset):
        '''
        dataset - объект класса Dataset
        Функция использует входной аргумент "dataset", 
        чтобы заполнить все атрибуты данного класса.
        '''
        # Сохраняем словари соответствия меток
        self.label2num = dataset.label2num
        self.num2label = dataset.num2label

        # Распаковываем сплиты
        self._train_X, self._train_y = dataset.train
        self._val_X, self._val_y = dataset.val
        self._test_X, self._test_y = dataset.test

        # Инициализация счетчиков
        self.vocab = set()
        self.spam = {}
        self.ham = {}

        # Считаем частоты слов по классам (multinomial Naive Bayes)
        for tokens, y in zip(self._train_X, self._train_y):
            is_spam = (y == self.label2num.get("spam", 1))
            table = self.spam if is_spam else self.ham
            for w in tokens:
                self.vocab.add(w)
                table[w] = table.get(w, 0) + 1

        self.Nvoc = len(self.vocab)
        self.Nspam = sum(self.spam.values())
        self.Nham = sum(self.ham.values())
        return self
    
    def inference(self, message):
        '''
        Функция принимает одно сообщение и, используя наивный байесовский алгоритм, определяет его как спам / не спам.
        '''
        # message может приходить строкой или уже списком токенов
        if isinstance(message, str):
            msg = message.lower()
            msg = re.sub(r"[^a-z]+", " ", msg)
            tokens = [t for t in msg.split() if t]
        else:
            tokens = list(message)

        # Приоры по сообщениям
        y_train = self._train_y
        n = len(y_train)
        n_spam = int(np.sum(y_train == self.label2num.get("spam", 1)))
        n_ham = n - n_spam
        # чтобы избежать log(0)
        pspam = np.log((n_spam + 1) / (n + 2))
        pham = np.log((n_ham + 1) / (n + 2))

        alpha = self.alpha
        denom_spam = self.Nspam + alpha * self.Nvoc
        denom_ham = self.Nham + alpha * self.Nvoc

        for w in tokens:
            if w not in self.vocab:
                continue
            pspam += np.log((self.spam.get(w, 0) + alpha) / denom_spam)
            pham += np.log((self.ham.get(w, 0) + alpha) / denom_ham)

        return "spam" if pspam > pham else "ham"
    
    def validation(self):
        '''
        Функция предсказывает метки сообщений из набора данных validation,
        и возвращает точность предсказания меток сообщений.
        Вы должны использовать метод класса inference().
        '''
        preds = [self.inference(x) for x in self._val_X]
        true = [self.num2label[int(y)] for y in self._val_y]
        val_acc = float(np.mean([p == t for p, t in zip(preds, true)]))
        return val_acc 

    def test(self):
        '''
        Функция предсказывает метки сообщений из набора данных test,
        и возвращает точность предсказания меток сообщений.
        Вы должны использовать метод класса inference().
        '''
        preds = [self.inference(x) for x in self._test_X]
        true = [self.num2label[int(y)] for y in self._test_y]
        test_acc = float(np.mean([p == t for p, t in zip(preds, true)]))
        return test_acc


