import numpy as np
import re

class Dataset:
    def __init__(self, X, y):
        self._x = X # сообщения 
        self._y = y # метки ["spam", "ham"]
        self.train = None # кортеж из (X_train, y_train)
        self.val = None # кортеж из (X_val, y_val)
        self.test = None # кортеж из (X_test, y_test)
        self.label2num = {} # словарь, используемый для преобразования меток в числа
        self.num2label = {} # словарь, используемый для преобразования числа в метки
        self._transform()
        
    def __len__(self):
        return len(self._x)
    
    def _transform(self):
        '''
        Функция очистки сообщения и преобразования меток в числа.
        '''
        # Очистка текста + преобразование меток в числа.
        # Сообщения приводим к нижнему регистру и оставляем только латинские буквы.
        cleaned_X = []
        for msg in self._x:
            msg = str(msg).lower()
            msg = re.sub(r"[^a-z]+", " ", msg)
            tokens = [t for t in msg.split() if t]
            cleaned_X.append(tokens)
        self._x = np.array(cleaned_X, dtype=object)

        # Метки: ham -> 0, spam -> 1 (можно и наоборот — главное, чтобы было последовательно).
        uniq = sorted(set(map(str, self._y)))
        if "ham" in uniq and "spam" in uniq:
            uniq = ["ham", "spam"]
        self.label2num = {lab: i for i, lab in enumerate(uniq)}
        self.num2label = {i: lab for lab, i in self.label2num.items()}
        self._y = np.array([self.label2num[str(lab)] for lab in self._y], dtype=int)

    def split_dataset(self, val=0.1, test=0.1):
        '''
        Функция, которая разбивает набор данных на наборы train-validation-test.
        '''
        n = len(self)
        idx = np.random.permutation(n)
        n_test = int(round(n * test))
        n_val = int(round(n * val))
        n_train = n - n_val - n_test

        train_idx = idx[:n_train]
        val_idx = idx[n_train:n_train + n_val]
        test_idx = idx[n_train + n_val:]

        X_train, y_train = self._x[train_idx], self._y[train_idx]
        X_val, y_val = self._x[val_idx], self._y[val_idx]
        X_test, y_test = self._x[test_idx], self._y[test_idx]

        self.train = (X_train, y_train)
        self.val = (X_val, y_val)
        self.test = (X_test, y_test)
        return self.train, self.val, self.test
